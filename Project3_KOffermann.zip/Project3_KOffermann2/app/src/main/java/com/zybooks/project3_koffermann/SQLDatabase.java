package com.zybooks.project3_koffermann;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/* Course: CS-360 | SNHU
   Assignment: Project Three
   Name: Kerrian Offermann */

public class SQLDatabase extends SQLiteOpenHelper {

    // The name of the database
    private static final String DATABASE_NAME = "users";
    // The int of the database
    public static final int DATABASE_VERSION = 1;
    // The table name
    private static final String TABLE_NAME = "appusers";
    // The id column for the primary keys
    private static final String ID_COL = "id";
    // The user name column
    private static final String USERNAME_COLUMN = "username";
    // The password column
    private static final String PASSWORD_COLUMN = "password";
    // The fist name column
    private static final String FIRSTNAME_COLUMN = "firstname";
    // The last name column
    private static final String LASTNAME_COLUMN = "lastname";
    // The email column
    private static final String EMAIL_COLUMN = "email";
    // Constructor
    public SQLDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    // For matching columns with their data types
    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + USERNAME_COLUMN + " TEXT,"
                + PASSWORD_COLUMN + " TEXT,"
                + FIRSTNAME_COLUMN + " TEXT,"
                + LASTNAME_COLUMN + " TEXT,"
                + EMAIL_COLUMN + " TEXT)"
                ;

        // Execution of query
        db.execSQL(query);
    }

    // Method for adding users to the database
    public void addNewUser(String username, String firstName, String lastName, String email, String password) {

        // For writing variable creations to the database
        SQLiteDatabase db = this.getWritableDatabase();

        // For content value creation
        ContentValues values = new ContentValues();

        // For passing values with their keys
        values.put(USERNAME_COLUMN, username);
        values.put(PASSWORD_COLUMN, password);
        values.put(FIRSTNAME_COLUMN, firstName);
        values.put(LASTNAME_COLUMN, lastName);
        values.put(EMAIL_COLUMN, email);


        // Adding values to the table
        db.insert(TABLE_NAME, null, values);

        // Closing database after adding what is needed
        db.close();
    }

    // For upgrading table if a table already exists
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // For using a query to find user's login
    public boolean checkLogin(String username, String password) { // Check database for registered username and password
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE username = ? AND password = ?",
                new String[]{username, password});
        if (cursor != null) {
            if(cursor.getCount() > 0) // If cursor finds something then return as true
            {
                cursor.close();
                return true;
            }
        }
        return false; // If it finds nothing then return as false
    }

}
