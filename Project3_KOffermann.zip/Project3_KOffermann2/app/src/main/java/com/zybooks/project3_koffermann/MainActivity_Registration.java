package com.zybooks.project3_koffermann;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/* Course: CS-360 | SNHU
   Assignment: Project Three
   Name: Kerrian Offermann */

public class MainActivity_Registration extends AppCompatActivity {

    // Creating variables for different text fields and connected to the SQL Database
        public EditText username, firstNameEdt, lastNameEdt, passwordEdt, emailEdt;
        private SQLDatabase sqlDatabase;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_registration);


        // Initializing variables and connecting their to their activity IDs
        username = findViewById(R.id.idEdtUserName);
        firstNameEdt = findViewById(R.id.idEdtFirstName);
        lastNameEdt = findViewById(R.id.idEdtLastName);
        passwordEdt = findViewById(R.id.idEdtPassword);
        emailEdt = findViewById(R.id.idEdtEmail);
        Button addUserBtn = findViewById(R.id.idAddUserBtn);
        Button returnBtn = findViewById(R.id.idReturnBtn);

        sqlDatabase = new SQLDatabase(MainActivity_Registration.this);

            // onClick listener for registering
        addUserBtn.setOnClickListener(v -> {

            // Lines for taking text entered into the five fields listed
            String userName = username.getText().toString();
            String firstName = firstNameEdt.getText().toString();
            String lastName = lastNameEdt.getText().toString();
            String password = passwordEdt.getText().toString();
            String email = emailEdt.getText().toString();

            // Making sure fields are not empty and warning users if they are
            if (userName.isEmpty() && firstName.isEmpty() && lastName.isEmpty() && password.isEmpty() && email.isEmpty()) {
                Toast.makeText(MainActivity_Registration.this, "Please enter missing information", Toast.LENGTH_SHORT).show();
                return;
            }

            // Method to add new users to the database
            sqlDatabase.addNewUser(userName, firstName, lastName, password, email);

            // Toast message for successful registration
            Toast.makeText(MainActivity_Registration.this, "Registration successful!", Toast.LENGTH_SHORT).show();
            username.setText("");
            firstNameEdt.setText("");
            lastNameEdt.setText("");
            passwordEdt.setText("");
            emailEdt.setText("");

        });

        // Return button that brings users back to the main login screen
        returnBtn.setOnClickListener(v -> startActivity(new Intent(MainActivity_Registration.this, MainActivity.class)));

    }
}