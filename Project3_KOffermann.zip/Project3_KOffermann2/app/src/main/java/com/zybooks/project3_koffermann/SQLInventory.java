package com.zybooks.project3_koffermann;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/* Course: CS-360 | SNHU
   Assignment: Project Three
   Name: Kerrian Offermann */

public class SQLInventory extends SQLiteOpenHelper {

    // The name of the database
    private static final String DATABASE_NAME = "inventory";
    // The int of the database
    private static final int DATABASE_VERSION = 1;
    // The table name
    private static final String TABLE_NAME = "items";
    // The id column for the primary keys
    private static final String KEY_COLUMN = "keyID";
    // The item name column
    private static final String ITEMNAME_COLUMN = "itemName";
    // The quantity column
    private static final String QUANTITY_COLUMN = "quantity";
    // The itemID column
    private static final String ITEMID_COLUMN = "itemID";
    // The phoneNumber column
    private static final String PHONE_COLUMN = "phoneNumber";



    // Constructor for database handler.
    public SQLInventory(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }


    @Override
    public void onCreate(SQLiteDatabase inventory) {
        // The onCreate for database that matches columns with their types
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + KEY_COLUMN + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + ITEMNAME_COLUMN + " TEXT,"
                + QUANTITY_COLUMN + " TEXT,"
                + ITEMID_COLUMN + " TEXT,"
                + PHONE_COLUMN + " TEXT)";


        // Execution of above query
        inventory.execSQL(query);
    }

    // Method for adding items to the database
    public void addItem(String itemName, String quantity, String itemID) {

        // For writing variable creations to the database
        SQLiteDatabase inventory = this.getWritableDatabase();

        // For content value creation
        ContentValues values = new ContentValues();

        // For passing values with their keys
        values.put(ITEMNAME_COLUMN, itemName);
        values.put(QUANTITY_COLUMN, quantity);
        values.put(ITEMID_COLUMN, itemID);

        // Adding values to the table
        inventory.insert(TABLE_NAME, null, values);

        // Closing database after adding what is needed
        inventory.close();
    }

    // Add number for SMS text
    public void addPhone(String phone) {

        // For writing variable creations to the database
        SQLiteDatabase inventory = this.getWritableDatabase();

        // For content value creation
        ContentValues values = new ContentValues();

        // For passing values with their keys
        values.put(PHONE_COLUMN, phone);

        // Adding values to the table
        inventory.insert(TABLE_NAME, null, values);

        // Closing database after adding what is needed
        inventory.close();
    }

    @Override
    public void onUpgrade(SQLiteDatabase inventory, int oldVersion, int newVersion) {
        // For upgrading table if a table already exists
        inventory.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(inventory);
    }

    // Method for finding an item
    public boolean checkItem(String itemID){
        SQLiteDatabase inventory = this.getReadableDatabase();
        Cursor cursor = inventory.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE itemID = ?",
                new String[]{itemID});
        if (cursor != null) {
            if(cursor.getCount() > 0)
            {
                cursor.close();
                return true; // If item is found then return true
            }
        }
        return false; // If item is not found then return false
    }

    // Method for checking phone number
    public boolean checkPhone(String phoneNumber){
        SQLiteDatabase inventory = this.getReadableDatabase();
        Cursor cursor = inventory.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE phoneNumber = ?",
                new String[]{phoneNumber});
        if (cursor != null) {
            if(cursor.getCount() > 0)
            {
                cursor.close();
                return true; // If number is found then return true
            }
        }
        return false; // If number is not found then return false
    }


    // Method for checking quantity
    public boolean checkQuantity(String quantity){
        SQLiteDatabase inventory = this.getReadableDatabase();

        Cursor cursor = inventory.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE quantity = ?", new String[]{ quantity });
        if (cursor != null) {
            if (cursor.getCount() > 0) {
                cursor.close();
                return true;
            }
        }
        return false;
    }


    // Method for deleting items
    public void deleteItem(String itemID) {
        SQLiteDatabase inventory = getWritableDatabase();
        int rowsDeleted = inventory.delete(TABLE_NAME, ITEMID_COLUMN + " = ?",
                new String[] {itemID});
    }


    // Method for updating items
    public void updateItem(String itemName, String quantity, String itemID) {
        SQLiteDatabase inventory = getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(ITEMNAME_COLUMN, itemName);
        values.put(QUANTITY_COLUMN, quantity);
        values.put(ITEMID_COLUMN, itemID);
        inventory.update(TABLE_NAME, values, ITEMNAME_COLUMN + " = ?" , new String[] { itemName });
    }




    public Cursor getAllItems() {
        SQLiteDatabase inventory = this.getReadableDatabase();
        return inventory.rawQuery("SELECT * FROM " + TABLE_NAME, null);

    }


}
