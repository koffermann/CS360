package com.zybooks.project3_koffermann;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/* Course: CS-360 | SNHU
   Assignment: Project Three
   Name: Kerrian Offermann */

public class MainActivity2 extends AppCompatActivity {

    // Creating variables for different text fields and connected to the SQL Database
    public EditText itemNameEdt;
    public EditText itemQuantityEdt;
    public EditText itemIDEdt;
    public EditText smsPhoneEdt;
    private SQLInventory dbi;

    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        itemNameEdt = findViewById(R.id.editItemName);
        itemQuantityEdt = findViewById(R.id.editQuantity);
        itemIDEdt = findViewById(R.id.editItemID);
        smsPhoneEdt = findViewById(R.id.editPhone);
        Button addItemBtn = findViewById(R.id.addbutton);
        Button deleteItemBtn = findViewById(R.id.deletebutton);
        Button showAllBtn = findViewById(R.id.allItemsButton);
        Button updateItemBtn = findViewById(R.id.updateitem);
        Button SMSBtn = findViewById(R.id.SMS);

        dbi = new SQLInventory(MainActivity2.this);


        // ADD ITEM BUTTON
        addItemBtn.setOnClickListener(v -> {
            // Lines for taking text entered into the fields listed
            String itemName = itemNameEdt.getText().toString();
            String itemQuantity = itemQuantityEdt.getText().toString();
            String itemID = itemIDEdt.getText().toString();

            // Making sure fields are not empty and warning users if they are
            if (itemName.isEmpty() || itemQuantity.isEmpty() || itemID.isEmpty()) {
                Toast.makeText(MainActivity2.this, "Please enter missing information", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean checkItem = dbi.checkItem(itemID);

            if(checkItem) {
                Toast.makeText(MainActivity2.this, "This item is already in the system.", Toast.LENGTH_SHORT).show();
            }

            else {
                // Method to add new items to the database
                dbi.addItem(itemName, itemQuantity, itemID);

                // Toast message for successful item add
                Toast.makeText(MainActivity2.this, "Item added successfully!", Toast.LENGTH_SHORT).show();
                itemNameEdt.setText("");
                itemQuantityEdt.setText("");
                itemIDEdt.setText("");
            }
        });


        // DELETE BUTTON
        deleteItemBtn.setOnClickListener(v -> {
            // Lines for taking text entered into the fields listed
            String itemID = itemIDEdt.getText().toString();
            boolean checkItem = dbi.checkItem(itemID);

            if(!checkItem) {
                Toast.makeText(MainActivity2.this, "Cannot delete. This item is not in the system.", Toast.LENGTH_SHORT).show();
            }

            // Making sure fields are not empty and warning users if they are
            if (itemID.isEmpty()) {
                Toast.makeText(MainActivity2.this, "Please enter missing information", Toast.LENGTH_SHORT).show();
            }

            else {
                // Method to add new items to the database
                dbi.deleteItem(itemID);
                Toast.makeText(MainActivity2.this, "This item has been deleted.", Toast.LENGTH_SHORT).show();
            }
        });


        // SHOW ALL BUTTON
        showAllBtn.setOnClickListener(v -> {

            SQLInventory dbi = new SQLInventory(MainActivity2.this);
            dbi.getWritableDatabase();

            Cursor cursor = dbi.getAllItems();
            cursor.moveToFirst();
            final TextView listItems = (TextView)findViewById(R.id.listTextView);
            itemNameEdt.setText(cursor.getString(0));

        });



        // UPDATE BUTTON
        updateItemBtn.setOnClickListener(v -> {
            // Updating items that exist in the database
            // Lines for taking text entered into the fields listed
            String itemName = itemNameEdt.getText().toString();
            String itemQuantity = itemQuantityEdt.getText().toString();
            String itemID = itemIDEdt.getText().toString();


            boolean checkItem = dbi.checkItem(itemName);

            if(checkItem) {
                Toast.makeText(MainActivity2.this, "This item name is already being used.", Toast.LENGTH_SHORT).show();
            }

            else {
                // Method to add new items to the database
                dbi.updateItem(itemName, itemQuantity, itemID);

                // Toast message for successful item add
                Toast.makeText(MainActivity2.this, "Item updated successfully!", Toast.LENGTH_SHORT).show();
                itemNameEdt.setText("");
                itemQuantityEdt.setText("");
                itemIDEdt.setText("");
            }

        });

        // SMS PERMISSION
        SMSBtn.setOnClickListener(view -> {

            String phoneNumber = smsPhoneEdt.getText().toString();
            String itemQuantity = itemQuantityEdt.getText().toString();


            // Request sms permission for the device
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.SEND_SMS)!= PackageManager.PERMISSION_GRANTED) {

                if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
                    Toast.makeText(this, "Permission will be needed for low inventory alerts.", Toast.LENGTH_LONG).show();
                }

                else {
                    ActivityCompat.requestPermissions(this,
                            new String[]{Manifest.permission.SEND_SMS}, 1);
                }
            }

            else {
                Toast.makeText(this, "SMS permission granted!", Toast.LENGTH_LONG).show();

                // Check if phone number is there
                boolean checkPhone = dbi.checkPhone(phoneNumber);
                boolean checkQuantity = dbi.checkQuantity(itemQuantity);

                if(checkPhone) { // If phone number is in database

                    if (Integer.parseInt(String.valueOf(checkQuantity)) < 3) { //And the quantity is less than 3
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phoneNumber, null, "Your stock is running low. Please restock ASAP.",
                                null, null); // Send SMS text notification
                    }
                }

                if(phoneNumber.isEmpty()) { // If phone number field is empty then send a toast message
                    Toast.makeText(MainActivity2.this, "Please enter a phone number for text alerts.", Toast.LENGTH_SHORT).show();
                }

            }
        });




    }
}