package com.zybooks.project3_koffermann;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/* Course: CS-360 | SNHU
   Assignment: Project Three
   Name: Kerrian Offermann */

public class MainActivity extends AppCompatActivity {

    public EditText userNameMain; // Initialize username field
    public EditText passwordMain; // Initialize password field
    private SQLDatabase db; // Initialize database

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    // initializing all our variable and connecting them to their components with their activity IDs
    userNameMain = findViewById(R.id.idUserName); // Initialize and connect username field
    passwordMain = findViewById(R.id.idPassword); // Initialize and connect password field
    Button loginBtn = findViewById(R.id.login); // Initialize and connect login button
    Button regBtn = findViewById(R.id.register); // Initialize and connect register button

    db = new SQLDatabase(MainActivity.this); // Call SQLDatabase for upcoming query

    // onClick listener for login button
        loginBtn.setOnClickListener(view -> {

            // Lines for taking text entered into the fields
            String loginUser = userNameMain.getText().toString();
            String loginPass = passwordMain.getText().toString();

            // Making sure fields are not empty and warning users if they are
            if (loginUser.isEmpty() && loginPass.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please enter missing information", Toast.LENGTH_SHORT).show();
                return;
            }

            // Call method in SQLDatabase that checks for user's login username and password
            boolean checkLogin = db.checkLogin(loginUser, loginPass);

            if (checkLogin) { // If checkLogin comes back true then open up the inventory page
                startActivity(new Intent(MainActivity.this, MainActivity2.class));
            }

            else { // If it comes back false for any reason then return unsuccessful
                Toast.makeText(MainActivity.this, "Login unsuccessful. Please try again.", Toast.LENGTH_SHORT).show();
            }



        });

    // onClick listener for register button
        // Clicking this button will change main screen to registration screen
        regBtn.setOnClickListener(view -> startActivity(new Intent(MainActivity.this, MainActivity_Registration.class)));

    }

}